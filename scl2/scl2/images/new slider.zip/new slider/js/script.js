
/*side background*/
var indexValue = 0;
function slideShow(){
  setTimeout(slideShow, 2500);
  var x;
  const img = document.getElementsByClassName("image");
  for(x = 0; x < img.length; x++){
    img[x].style.display = "none";
  }
  indexValue++;
  if(indexValue > img.length){indexValue = 1}
  img[indexValue -1].style.display = "block";
}
slideShow();
/*side background end*/
var width = 100;
var animation_speed = 700;
var time_val = 3000;
var current_slide = 1;

var $slider = $('#slider');
var $slide_container = $('.slides');
var $slides = $('.slide');

var interval;

$slides.each(function(index){
  $(this).css('left',(index*100)+'%');
});

function startSlider() {
  interval = setInterval(function() {
    $slide_container.animate({'left': '-='+(width+'%')}, animation_speed, function() {
      if (++current_slide === $slides.length) {
        current_slide = 1;
        $slide_container.css('left', 0);
      }
    });
  }, time_val);
}

startSlider();
/*slider Testonomia*/

/*slider end*/
/*sticky nav bar*/
startSlider();

window.onscroll = function() {myFunction()};
  
var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
/*sticky  end nav bar*/







